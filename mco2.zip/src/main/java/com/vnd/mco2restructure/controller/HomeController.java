package com.vnd.mco2restructure.controller;

import com.vnd.mco2restructure.model.ProgramData;
import com.vnd.mco2restructure.WindowManager;
import com.vnd.mco2restructure.component.NumberField;
import com.vnd.mco2restructure.component.SlidePopup;
import com.vnd.mco2restructure.component.VendingMachineButton;
import com.vnd.mco2restructure.menu.DependentItemEnum;
import com.vnd.mco2restructure.menu.IndependentItemEnum;
import com.vnd.mco2restructure.model.MaintenanceData;
import com.vnd.mco2restructure.model.vendingmachine.RegularVendingMachine;
import com.vnd.mco2restructure.model.vendingmachine.SpecialVendingMachine;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;

/**
 * Controller class for the home view.
 */
public class HomeController {
    private WindowManager windowManager;
    private ProgramData programData;
    @FXML private SlidePopup slidePopup;
    @FXML private TextField vndNameTextField;
    @FXML private ComboBox<String> vndTypeChoice;
    @FXML private VBox vndMachineButtonsLayout;
    @FXML private NumberField noOfSlotsNumberField;
    @FXML private NumberField slotCapacityNumberField;

    /**
     * Handles the action when the "Show Popup" button is clicked.
     * Shows the slide popup.
     */
    @FXML
    private void showPopup() {
        slidePopup.slideUpAnimation();
    }

    /**
     * Handles the action when the "Add Vending Machine" button is clicked.
     * Adds a new vending machine based on the entered data.
     */
    @FXML
    private void addVendingMachine() {
        // gets the no of slots and slot capacity. It has a minimum number of 8 and 10 respectively.
        int noOfSlots = Math.max(8, ((NumberFieldController) noOfSlotsNumberField.
                getLoader().getController()).getValue());
        int slotCapacity = Math.max(10, ((NumberFieldController) slotCapacityNumberField.
                getLoader().getController()).getValue());

        // creates a button for that specific vending machine
        VendingMachineButton vendingMachineButton = new VendingMachineButton(
                vndNameTextField.getText().isEmpty() ? "Vending Machine " +
                        (programData.getVendingMachines().size() + 1) : vndNameTextField.getText(),
                vndTypeChoice.getValue(), noOfSlots, slotCapacity
        );

        // handles button logic
        vendingMachineButton.setOnMouseClicked(event -> {
            programData.setCurrentVendingMachine(programData.getVendingMachines().get(vendingMachineButton));
            programData.setCurrentMaintenanceData(programData.getMaintenanceDatas().get(vendingMachineButton));
            IndependentItemEnum.setItemPrices(programData.getIndependentItemPrices().get(vendingMachineButton));
            DependentItemEnum.setItemPrices(programData.getDependentItemPrices().get(vendingMachineButton));
            windowManager.gotoVndFeaturesView();
            windowManager.setStockView(programData.getCurrentVendingMachine() instanceof SpecialVendingMachine);
            windowManager.resetCurrentFeaturesView();
        });

        vndMachineButtonsLayout.getChildren().add(vendingMachineButton);

        // Sets the type of vending machine to create
        if (vndTypeChoice.getValue().equalsIgnoreCase("Regular")) {
            System.out.println("Add regular vending machine");
            programData.getVendingMachines().put(vendingMachineButton, new RegularVendingMachine(noOfSlots, slotCapacity));
        } else {
            System.out.println("Add special vending machine");
            programData.getVendingMachines().put(vendingMachineButton, new SpecialVendingMachine(noOfSlots, slotCapacity));
        }
        // handles other data to be used in the program
        programData.getMaintenanceDatas().put(vendingMachineButton, new MaintenanceData());
        programData.getIndependentItemPrices().put(vendingMachineButton, IndependentItemEnum.createNewItemPrices());
        programData.getDependentItemPrices().put(vendingMachineButton, DependentItemEnum.createNewItemPrices());

        // reset the inputs
        vndTypeChoice.setValue("Regular");
        vndNameTextField.setText("");
        noOfSlotsNumberField.getTextField().setText("0");
        slotCapacityNumberField.getTextField().setText("0");
        slidePopup.slideDownAnimation();
    }

    /**
     * Sets the WindowManager for this controller.
     *
     * @param windowManager The WindowManager instance.
     */
    public void setWindowManager(WindowManager windowManager) {
        this.windowManager = windowManager;
    }

    /**
     * Sets the ProgramData for this controller.
     *
     * @param programData The ProgramData instance.
     */
    public void setProgramData(ProgramData programData) {
        this.programData = programData;
    }
}
