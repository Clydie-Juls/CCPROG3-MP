package com.vnd.mco2restructure.menu;

/**
 * This class represents that the item type is sellable
 */
public interface Sellable {
}
