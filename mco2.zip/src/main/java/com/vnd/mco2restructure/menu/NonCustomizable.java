package com.vnd.mco2restructure.menu;

/**
 * This class is an empty interface representing non-customizable item enums
 */
public interface NonCustomizable {
}
